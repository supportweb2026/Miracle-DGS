import { useState, useEffect } from 'react';
import { Divider } from 'antd';

import { Button, Row, Col, Descriptions, Statistic, Tag } from 'antd';
import { PageHeader } from '@ant-design/pro-layout';
import {
  EditOutlined,
  FilePdfOutlined,
  CloseCircleOutlined,
  RetweetOutlined,
  MailOutlined,
} from '@ant-design/icons';

import { useSelector, useDispatch } from 'react-redux';
import useLanguage from '@/locale/useLanguage';
import { erp } from '@/redux/erp/actions';

import { generate as uniqueId } from 'shortid';

import { selectCurrentItem } from '@/redux/erp/selectors';

import { DOWNLOAD_BASE_URL } from '@/config/serverApiConfig';
import { useMoney, useDate } from '@/settings';
import useMail from '@/hooks/useMail';
import { useNavigate } from 'react-router-dom';
import dayjs from 'dayjs';
import 'dayjs/locale/fr';
import { request } from '@/request'; 


const Service = ({ service, currentErp }) => {

  const { moneyFormatter } = useMoney();

  // Calcul de la durée entre la date de début et la date de fin
  //if( service.endDate && service.startDate ){
    const duration = dayjs(service.endDate || '1970-01-01').diff(dayjs(service.startDate || '1970-01-01'), 'day');
    //}
  
  // Calcul du total pour ce service
  console.log('before readservice');
  const totalService = duration > 0 ? service.dailyRate * duration * service.agentsNumber: 0;

  const agents = service.agentsNumber;

  return (
    <Row gutter={[12, 0]} key={service._id}>
      <Col className="gutter-row" span={4}>
        <p style={{ marginBottom: 5 }}>
          <strong>{service.service.name}</strong>
        </p>
        <p>{service.name}</p>
      </Col>
      <Col className="gutter-row" span={4}>
        <p
          style={{
            textAlign: 'right',
          }}
        >
          {moneyFormatter({ amount: service.dailyRate, currency_code: currentErp.currency })}
        </p>
      </Col>
      <Col className="gutter-row" span={4}>
        <p
          style={{
            textAlign: 'right', // Rajouter la variable {agent} juste après duration ici et faites la même chose dans le 2eme return pour l'intitulé
          }}
        >
          {duration} {duration === 1 ? 'jour' : 'jours'} 
        </p>
      </Col>
      <Col className="gutter-row" span={4}>
        <p
          style={{
            textAlign: 'right', // Rajouter la variable {agent} juste après duration ici et faites la même chose dans le 2eme return pour l'intitulé
          }}
        >
          {agents}  
        </p>
      </Col>
    
      
      <Col className="gutter-row" span={5}>
        <p
          style={{
            textAlign: 'right',
            fontWeight: '700',
          }}
        >
          {moneyFormatter({ amount: totalService, currency_code: currentErp.currency })}
        </p>
      </Col>
      <Divider dashed style={{ marginTop: 0, marginBottom: 15 }} />
    </Row>
  );
};

export default function ReadService({ config, selectedService }) {
  const openPreFilledEmail = (email, name, entity) => {
    const subject = encodeURIComponent("Votre " + entity);
    const body = encodeURIComponent(`Bonjour ${name},
  
  Veuillez trouver ci-joint votre ${entity}.
  
  Cordialement,
  Votre équipe DGS
  Centre médicaux
  Libreville, Gabon
  dgsgabon2.0@gmail.com
  +247 074 80 87 81
  www.dgs-gabon.com`);
  
    const mailtoLink = `mailto:${email}?subject=${subject}&body=${body}`;
    window.location.href = mailtoLink;
  };
 
  const handleSendEmail = async (id, entity) => {
    console.log('sendEmail id=',id,' entity=',entity);
    if(entity=='invoice') {
      console.log('on est dans invoice');
      try {
              const response = await request.read({
                entity: 'invoice',
                id: id,
              });
              console.log('response=',response);
              console.log('email=',response.result.client.email);
              console.log('name=',response.result.client.name);
              const email=response.result.client.email;
              const name = response.result.client.name
              openPreFilledEmail(email,name,'facture');

            }
              catch {

              }
    }
    else if(entity=='payment') {
      console.log('on est dans payment');
    }
    else  if(entity=='quote') {
      console.log('on est dans quote');
      try {
        const response = await request.read({
          entity: 'quote',
          id: id,
        });
        console.log('response=',response);
        console.log('email=',response.result.client.email);
        console.log('name=',response.result.client.name);
        const email=response.result.client.email;
        const name = response.result.client.name
        openPreFilledEmail(email,name,'devis');

      }
        catch {

        }
    }
  }
  const translate = useLanguage();
  const { entity, ENTITY_NAME } = config;
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { moneyFormatter } = useMoney();
  const { send, isLoading: mailInProgress } = useMail({ entity });

  const { result: currentResult } = useSelector(selectCurrentItem);
  const resetErp = {
    status: '',
    client: {
      name: '',
      email: '',
      phone: '',
      address: '',
    },
    subTotal: 0,
    taxTotal: 0,
    taxRate: 0,
    total: 0,
    credit: 0,
    number: 0,
    year: 0,
  };

  const [servicesList, setServicesList] = useState([]);
  const [currentErp, setCurrentErp] = useState(selectedService ?? resetErp);
  const [client, setClient] = useState({});

  useEffect(() => {
    if (currentResult) {
      const { services, invoice, ...others } = currentResult;

      if (services) {
        console.log('liste des services services tz ReadService:',services);
        setServicesList(services);

        setCurrentErp(currentResult);
      } else if (invoice.services) {
        setServicesList(invoice.services);
        setCurrentErp({ ...invoice.services, ...others, ...invoice });
      }
    }
    return () => {
      setServicesList([]);
      setCurrentErp(resetErp);
    };
  }, [currentResult]);

  console.log('liste des services servicesList tz ReadService:',servicesList);


  useEffect(() => {
    if (currentErp?.client) {
      setClient(currentErp.client);
    }
  }, [currentErp]);

  return (
    <>
      <PageHeader
        onBack={() => {
          navigate(`/${entity.toLowerCase()}`);
        }}
        title={`${ENTITY_NAME} # ${currentErp.number}/${currentErp.year || ''}`}
        ghost={false}
        tags={[
          <span key="status">{currentErp.status && translate(currentErp.status)}</span>,
          currentErp.paymentStatus && (
            <span key="paymentStatus">
              {' '}
              {currentErp.paymentStatus && translate(currentErp.paymentStatus)}
            </span>
          ),
        ]}
        extra={[
          <Button
            key={`${uniqueId()}`}
            onClick={() => {
              navigate(`/${entity.toLowerCase()}`);
            }}
            icon={<CloseCircleOutlined />}
          >
            {translate('Close')}
          </Button>,
          <Button
            key={`${uniqueId()}`}
            onClick={() => {
              window.open(
                `${DOWNLOAD_BASE_URL}${entity}/${entity}-${currentErp._id}.pdf`,
                '_blank'
              );
            }}
            icon={<FilePdfOutlined />}
          >
            {translate('Download PDF')}
          </Button>,
          <Button
            key={`${uniqueId()}`}
            loading={mailInProgress}
            onClick={() => handleSendEmail(currentErp._id, entity)}

            icon={<MailOutlined />}
          >
            {translate('Send by Email')}
          </Button>,
          <Button
            key={`${uniqueId()}`}
            onClick={() => {
              dispatch(erp.convert({ entity, id: currentErp._id }));
            }}
            icon={<RetweetOutlined />}
            style={{ display: entity === 'quote' ? 'inline-block' : 'none' }}
          >
            {translate('Convert to Invoice')}
          </Button>,

          <Button
            key={`${uniqueId()}`}
            onClick={() => {
              dispatch(
                erp.currentAction({
                  actionType: 'update',
                  data: currentErp,
                })
              );
              navigate(`/${entity.toLowerCase()}/update/${currentErp._id}`);
            }}
            type="primary"
            icon={<EditOutlined />}
          >
            {translate('Edit')}
          </Button>,
        ]}
        style={{
          padding: '20px 0px',
        }}
      >
        <Row>
          <Statistic title="Status" value={(() => {
            switch (currentErp.status) {
              case 'draft':
                return 'Brouillon';
              case 'pending':
                return 'En Attente';
              case 'sent':
                return 'Envoyé';
              default:
                return currentErp.status;
            }
          })()}  />
          <Statistic
            title={translate('SubTotal')}
            value={moneyFormatter({
              amount: currentErp.subTotal,
              currency_code: currentErp.currency,
            })}
            style={{
              margin: '0 32px',
            }}
          />
          <Statistic
            title={translate('Total')}
            value={moneyFormatter({ amount: currentErp.total, currency_code: currentErp.currency })}
            style={{
              margin: '0 32px',
            }}
          />
          <Statistic
            title={translate('Paid')}
            value={moneyFormatter({
              amount: currentErp.credit,
              currency_code: currentErp.currency,
            })}
            style={{
              margin: '0 32px',
            }}
          />
        </Row>
      </PageHeader>

      <Divider dashed />
      <Descriptions title={`Client : ${currentErp.client.name}`}>
        <Descriptions.Item label={translate('Address')}>{client.address}</Descriptions.Item>
        <Descriptions.Item label={translate('email')}>{client.email}</Descriptions.Item>
        <Descriptions.Item label={translate('Phone')}>{client.phone}</Descriptions.Item>
      </Descriptions>
      <Divider />

      <Row gutter={[12, 0]}>
        <Col className="gutter-row" span={4}>
          <p>
            <strong>{translate('Service')}</strong>
          </p>
        </Col>
        <Col className="gutter-row" span={4}>
          <p
            style={{
              textAlign: 'right',
            }}
          >
            <strong>{translate('Tarif journalier')}</strong>
          </p>
        </Col>
        <Col className="gutter-row" span={4}>
          <p
            style={{
              textAlign: 'right',
            }}
          >
            <strong>{translate('Durée')}</strong>
          </p>
        </Col>
        <Col className="gutter-row" span={4}>
          <p
            style={{
              textAlign: 'right',
            }}
          >
            <strong>{translate('Agents')}</strong>
          </p>
        </Col>
        
            

        <Col className="gutter-row" span={5}>
          <p
            style={{
              textAlign: 'right',
            }}
          >
            <strong>{translate('Total')}</strong>
          </p>
        </Col>
        <Divider />
      </Row>

      {servicesList.map((service) => (
        <Service key={service._id} service={service} currentErp={currentErp} />
      ))}

      <div
        style={{
          width: '300px',
          float: 'right',
          textAlign: 'right',
          fontWeight: '700',
        }}
      >
        <Row gutter={[12, -5]}>
          <Col className="gutter-row" span={12}>
            <p>{translate('Sub Total')} :</p>
          </Col>
        
          <Col className="gutter-row" span={12}>
            <p>
              {moneyFormatter({ amount: currentErp.subTotal, currency_code: currentErp.currency })}
            </p>
          </Col>
           {/* Ajout du total des taxes */}
    <Col className="gutter-row" span={12}>
      <p>{translate('Total des Taxes')} :</p>
    </Col>
    <Col className="gutter-row" span={12}>
      <p>
        {moneyFormatter({ amount: currentErp.taxTotal, currency_code: currentErp.currency })}
      </p>
    </Col>
          <Col className="gutter-row" span={12}>
            <p>
              <strong>{translate('Total')}</strong> :
            </p>
          </Col>

          <Col className="gutter-row" span={12}>
            <p>
              <strong>
                {moneyFormatter({ amount: currentErp.total, currency_code: currentErp.currency })}
              </strong>
            </p>
          </Col>
        </Row>
      </div>
    </>
  );
}
