import { useLayoutEffect, useEffect, useState } from 'react';
import { Row, Col, Button } from 'antd';
import { PlusOutlined, EditOutlined, DeleteOutlined, DownloadOutlined, MailOutlined } from '@ant-design/icons';

import CreateForm from '@/components/CreateForm';
import UpdateForm from '@/components/UpdateForm';
import DeleteModal from '@/components/DeleteModal';
import ReadItem from '@/components/ReadItem';

import SearchItem from '@/components/SearchItem';
import DataTable from '@/components/DataTable/DataTable';

import { useDispatch, useSelector } from 'react-redux';

import { selectCurrentItem } from '@/redux/crud/selectors';
import useLanguage from '@/locale/useLanguage';
import { crud } from '@/redux/crud/actions';
import { useCrudContext } from '@/context/crud';
import { request } from '@/request'; 

import { CrudLayout } from '@/layout';
import { DOWNLOAD_BASE_URL } from '@/config/serverApiConfig';

function SidePanelTopContent({ config, formElements, withUpload }) {
  const translate = useLanguage();
  const isContractEntity = config.entity === 'contract';
  console.log('isContractEntity:',isContractEntity);
  const { entity, ENTITY_NAME } = config; //tizi
  const { crudContextAction, state } = useCrudContext();
  const { deleteModalLabels } = config;
  const { modal, editBox } = crudContextAction;

  const { isReadBoxOpen, isEditBoxOpen } = state;
  const { result: currentItem } = useSelector(selectCurrentItem);
  const dispatch = useDispatch();

  const [labels, setLabels] = useState('');
  useEffect(() => {
    if (currentItem) {
      const currentlabels = deleteModalLabels.map((x) => currentItem[x]).join(' ');

      setLabels(currentlabels);
    }
  }, [currentItem]);

  const removeItem = () => {
    dispatch(crud.currentAction({ actionType: 'delete', data: currentItem }));
    modal.open();
  };
  const editItem = () => {
    dispatch(crud.currentAction({ actionType: 'update', data: currentItem }));
    editBox.open();
  };
  const handleDownload = (record) => {
    console.log('record:',record);
      window.open(`${DOWNLOAD_BASE_URL}${entity}/${entity}-${record._id}.pdf`, '_blank');
    };
    const handleSendEmail= async (id,b) => {
      console.log('handlesendemail a=',id,' b=',b)
      try {
        const response = await request.read({
          entity: 'contract',
          id: id,
        });
        console.log('response=',response);
        console.log('email=',response.result.client.email);
        console.log('name=',response.result.client.name);
        const email=response.result.client.email;
        const name = response.result.client.name
        const subject = encodeURIComponent("Votre contrat");
        const body = encodeURIComponent(`Bonjour ${name},
      
      Veuillez trouver ci-joint votre contrat.
      
      Cordialement,
      Votre équipe DGS
      Centre médicaux
      Libreville, Gabon
      dgsgabon2.0@gmail.com
      +247 074 80 87 81
      www.dgs-gabon.com`);
      
        const mailtoLink = `mailto:${email}?subject=${subject}&body=${body}`;
        window.location.href = mailtoLink;
      }
        catch {

        }
    }

  const show = isReadBoxOpen || isEditBoxOpen ? { opacity: 1 } : { opacity: 0 };
  return (
    <>
      <Row style={show} gutter={(24, 24)}>
        <Col span={10}>
        </Col>
        <Col span={14}>
       
        {isContractEntity && (
          <>
            <Button
            onClick={() => handleDownload(currentItem)} // Passer l'objet `record` ici
            type="primary"
              icon={<DownloadOutlined />}
              size="small"
              style={{ float: 'right', marginLeft: '5px', marginTop: '10px' }}
            >
              {translate('Télécharger')}
            </Button>
            <Button
            onClick={() => handleSendEmail(currentItem._id, 'contract')}
            type="default"
            icon={<MailOutlined />}
            size="small"
            style={{ float: 'right', marginTop: '10px' }}
          >
            {translate('Envoyer par mail')}
          </Button>
        </>
          )}
          <Button
            onClick={removeItem}
            type="text"
            icon={<DeleteOutlined />}
            size="small"
            style={{ float: 'right', marginLeft: '5px', marginTop: '10px' }}
          >
            {translate('remove')}
          </Button>
          <Button
            onClick={editItem}
            type="text"
            icon={<EditOutlined />}
            size="small"
            style={{ float: 'right', marginLeft: '0px', marginTop: '10px' }}
          >
            {translate('edit')}
          </Button>
        </Col>

        <Col span={24}>
          <div className="line"></div>
        </Col>
        <div className="space10"></div>
      </Row>
      <ReadItem config={config} />
      <UpdateForm config={config} formElements={formElements} withUpload={withUpload} />
    </>
  );
}

function FixHeaderPanel({ config }) {
  const { crudContextAction } = useCrudContext();

  const { collapsedBox } = crudContextAction;

  const addNewItem = () => {
    collapsedBox.close();
  };

  return (
    <Row gutter={8}>
      <Col className="gutter-row" span={21}>
        <SearchItem config={config} />
      </Col>
      <Col className="gutter-row" span={3}>
        <Button onClick={addNewItem} block={true} icon={<PlusOutlined />}></Button>
      </Col>
    </Row>
  );
}

function CrudModule({ config, createForm, updateForm, withUpload = false }) {
  const dispatch = useDispatch();
  console.log('tizi crudmodule config',config);
  console.log('updateForm',updateForm);


  useLayoutEffect(() => {
    dispatch(crud.resetState());
  }, []);

  return (
    <CrudLayout
      config={config}
      fixHeaderPanel={<FixHeaderPanel config={config} />}
      sidePanelBottomContent={
        <CreateForm config={config} formElements={createForm} withUpload={withUpload} />
      }
      sidePanelTopContent={
        <SidePanelTopContent config={config} formElements={updateForm} withUpload={withUpload} />
      }
    >
      <DataTable config={config} />
      <DeleteModal config={config} />
    </CrudLayout>
  );
}

export default CrudModule;
