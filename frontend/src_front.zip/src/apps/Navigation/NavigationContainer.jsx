import { useState, useEffect } from 'react';

import { Link, useLocation, useNavigate } from 'react-router-dom';

import { Button, Drawer, Layout, Menu } from 'antd';



import { useAppContext } from '@/context/appContext';



import useLanguage from '@/locale/useLanguage';

import logoIcon from '@/style/images/logo-dgs.JPG';

import logoText from '@/style/images/logo_miracle_text.jpg';



import useResponsive from '@/hooks/useResponsive';



import {

  SettingOutlined,

  CustomerServiceOutlined,

  ContainerOutlined,

  FileSyncOutlined,

  DashboardOutlined,

  TagOutlined,

  TagsOutlined,

  UserOutlined,

  CreditCardOutlined,

  MenuOutlined,

  FileOutlined,

  ShopOutlined,

  FilterOutlined,

  WalletOutlined,

  ReconciliationOutlined,

  DollarCircleOutlined ,

  AppstoreAddOutlined ,

  AppstoreOutlined ,
  PayCircleOutlined,
  FileSearchOutlined,
  EnvironmentOutlined,
  ShoppingCartOutlined ,
  BarChartOutlined,
  BuildOutlined ,
  SecurityScanOutlined ,



} from '@ant-design/icons';



const { Sider } = Layout;



export default function Navigation() {

  const { isMobile } = useResponsive();



  return isMobile ? <MobileSidebar /> : <Sidebar collapsible={false} />;

}



function Sidebar({ collapsible, isMobile = false }) {

  let location = useLocation();



  const { state: stateApp, appContextAction } = useAppContext();

  const { isNavMenuClose } = stateApp;

  const { navMenu } = appContextAction;

  const [showLogoApp, setLogoApp] = useState(isNavMenuClose);

  const [currentPath, setCurrentPath] = useState(location.pathname.slice(1));



  const translate = useLanguage();

  const navigate = useNavigate();



  const items = [

    {

      key: 'dashboard',

      icon: <DashboardOutlined />,

      label: <Link to={'/'}>{translate('dashboard')}</Link>,

    },

    {

      key: 'customer',

      icon: <CustomerServiceOutlined />,

      label: <Link to={'/customer'}>{translate('customers')}</Link>,

    },
    {
      key: 'Contracts',
      label: <Link to={'/contracts'}>{'Contrats'}</Link>,
      icon: <FileSearchOutlined />,
    },

    {
      key: 'Products',
      label: <Link to={'/products'}>{'Produits'}</Link>,
      icon: <ShoppingCartOutlined   />,
    },
    {
      key: 'Service',
      label: <Link to={'/service'}>{'Services'}</Link>,
      icon: <SecurityScanOutlined      />,
    },

    {

      key: 'invoice',

      icon: <ContainerOutlined />,

      label: <Link to={'/invoice'}>{translate('invoices')}</Link>,

    },

    {

      key: 'quote',

      icon: <FileSyncOutlined />,

      label: <Link to={'/quote'}>{translate('quote')}</Link>,

    },

    {

      key: 'payment',

      icon: <CreditCardOutlined />,

      label: <Link to={'/payment'}>{translate('payments')}</Link>,

    },



    {

      key: 'paymentMode',

      label: <Link to={'/payment/mode'}>{translate('payments_mode')}</Link>,

      icon: <WalletOutlined />,

    },

    {

      key: 'taxes',

      label: <Link to={'/taxes'}>{translate('taxes')}</Link>,

      icon: <ShopOutlined />,

    },

    {

      key: 'expense',

      label: <Link to={'/expense'}>{translate('Dépenses')}</Link>,

      icon: <DollarCircleOutlined />,

    },

    {

      key: 'ExpenseCategory',

      label: <Link to={'/expenseCategory'}>{'Catégorie de dépenses'}</Link>,

      icon: <AppstoreAddOutlined  />,

    },
    {
  key: 'PayrollManagement',
  label: <Link to={'/payrollManagement'}>{'Gestion Paie'}</Link>,
  icon: <PayCircleOutlined />,
},
{
  key: 'Employees',
  label: <Link to={'/employees'}>{'Employés'}</Link>,
  icon: <UserOutlined />,  // Icône pour Employés
},
{
  key: 'Location',
  label: <Link to={'/location'}>{'Localisation'}</Link>,
  icon: <EnvironmentOutlined />,  // Nouvelle icône pour Localisation
},
{
  key: 'Report',
  label: <Link to={'/report'}>{'Rapport'}</Link>,
  icon: <BarChartOutlined />,  // Nouvelle icône pour Localisation
},
    {

      key: 'generalSettings',

      label: <Link to={'/settings'}>{translate('settings')}</Link>,

      icon: <SettingOutlined />,

    },
/*
    {

      key: 'about',

      label: <Link to={'/about'}>{translate('about')}</Link>,

      icon: <ReconciliationOutlined />,

    },*/

  ];



  useEffect(() => {

    if (location)

      if (currentPath !== location.pathname) {

        if (location.pathname === '/') {

          setCurrentPath('dashboard');

        } else setCurrentPath(location.pathname.slice(1));

      }

  }, [location, currentPath]);



  useEffect(() => {

    if (isNavMenuClose) {

      setLogoApp(isNavMenuClose);

    }

    const timer = setTimeout(() => {

      if (!isNavMenuClose) {

        setLogoApp(isNavMenuClose);

      }

    }, 200);

    return () => clearTimeout(timer);

  }, [isNavMenuClose]);

  const onCollapse = () => {

    navMenu.collapse();

  };



  return (

    <Sider

      collapsible={collapsible}

      collapsed={collapsible ? isNavMenuClose : collapsible}

      onCollapse={onCollapse}

      className="navigation"

      width={256}

      style={{

        overflow: 'auto',

        height: '100vh',



        position: isMobile ? 'absolute' : 'relative',

        bottom: '20px',

        ...(!isMobile && {

          // border: 'none',

          ['left']: '20px',

          top: '20px',

          // borderRadius: '8px',

        }),

      }}

      theme={'light'}

    >

      <div

        className="logo"

        onClick={() => navigate('/')}

        style={{

          cursor: 'pointer',

        }}

      >



<div>

        <img src={logoIcon} alt="Logo" style={{ marginLeft: '-80px', marginTop: '-45px', height: '175px', paddingBottom : '15px' }} />



        

</div>

{!showLogoApp && (

                  <img

                    src={logoText}

                    alt="Logo"

                    style={{

                      marginTop: '-28px',

                      marginLeft: '-40px',

                      height: '120px',

                    }}

                  />

                )}  

      </div>

      <Menu

        items={items}

        mode="inline"

        theme={'light'}

        selectedKeys={[currentPath]}

        style={{

          width: 256,

        }}

      />

    </Sider>

  );

}



function MobileSidebar() {

  const [visible, setVisible] = useState(false);

  const showDrawer = () => {

    setVisible(true);

  };

  const onClose = () => {

    setVisible(false);

  };



  return (

    <>

      <Button

        type="text"

        size="large"

        onClick={showDrawer}

        className="mobile-sidebar-btn"

        style={{ ['marginLeft']: 25 }}

      >

        <MenuOutlined style={{ fontSize: 18 }} />

      </Button>

      <Drawer

        width={250}

        // style={{ backgroundColor: 'rgba(255, 255, 255, 1)' }}

        placement={'left'}

        closable={false}

        onClose={onClose}

        open={visible}

      >

        <Sidebar collapsible={false} isMobile={true} />

      </Drawer>

    </>

  );

}