import React from 'react';
import { Form, Input, Select, DatePicker, Button } from 'antd';
import useLanguage from '@/locale/useLanguage';
import AutoCompleteAsync from '@/components/AutoCompleteAsync';  // Composant pour récupérer la liste d'entités
import { request } from '@/request';  // Pour les appels API si nécessaire
import { useState, useEffect, useRef } from 'react';
import { useSelector } from 'react-redux';


import { selectFinanceSettings } from '@/redux/settings/selectors';

export default function ContractForm({ isUpdateForm = false }) {
  const translate = useLanguage();
  const [servicesList, setServicesList] = useState([]);
  const [dailyRate, setDailyRate] = useState([]);
//const [selectedPaymentMode,setSelectedPaymentMode]= useState([]);
  const { last_invoice_number } = useSelector(selectFinanceSettings);
  const { last_contract_number } = useSelector(selectFinanceSettings);
console.log('last_invoice_number=',last_invoice_number);
console.log('last_contract_number=',last_contract_number);

const [lastNumber, setLastNumber] = useState(() => Number(last_contract_number) + Number(1));

  const [paymentMode, setPaymentMode] = useState(null); // État pour suivre le mode de paiement sélectionné
  useEffect(() => {
    if (last_contract_number !== undefined && last_contract_number !== null) {
      setLastNumber(Number(last_contract_number) + Number(1));
    }
  }, [last_contract_number]);
  const handleServiceChange = (value) => {
    console.log('appel');
    // Trouver le service choisi dans la liste des services
    const selectedService = servicesList.find(service => service.label === value);
    console.log('selectedService:',selectedService);
console.log('...',selectedService.value);
   /* if (selectedService) {
      setDailyRate(selectedService.value);
    }
    console.log('dailyrate:',dailyRate);*/
  };

  const fetchAllServices = async () => {
    console.log('fetchallservice tizi macadam');
    let allServices = [];
  
    try {
      console.log('appel request');
      const response = await request.list({ entity: 'service' });
      console.log('recu ^response');

      if (response.success && response.result && Array.isArray(response.result)) {
        allServices = response.result;
        console.log('recup sucess');
        console.log(allServices);
      } else {
        console.log("Aucun service trouvé.");
        return; // Sortir de la fonction si aucun service n'est trouvé
      }
  
      let servicesList = allServices.map(service => ({
        label: service.name,   
        value: service.tauxJournalier 
      }));
  
      console.log("Services sous forme de label-value:", servicesList);
  
      
  
      // Si vous voulez mettre à jour l'état service, faites-le aussi ici si nécessaire
      setServicesList(servicesList);
      console.log("Services sous forme de Map:", servicesList);
  
      // Retourner la Map des services
      return servicesList;
    } catch (error) {
      console.error("Erreur lors de la récupération des services :", error);
    }
  };
  
  useEffect(() => {
    // Appel de la fonction fetchAllServices qui gère déjà tout le traitement
    const getServices = async () => {
      const result = await fetchAllServices();
      if (result) {
        setServicesList(result); // Met à jour l'état avec la liste des services traitée
        console.log(result);
      }
    };
    getServices();
  }, []); 
  // Fonction appelée lorsqu'il y a un changement dans le mode de paiement
  const handlePaymentModeChange = async (id) => {
    try {
console.log('paymentMode id=',id);
      const paymentMode = await request.read({ entity: 'paymentmode', id });
      console.log('paymentMode result all=',paymentMode);

      console.log('paymentMode=',paymentMode.result.name);
      if (paymentMode  ) {
        const paymentModeName = paymentMode.result.name;  // Récupère le nom du mode de paiement
        console.log('Nom du mode de paiement:', 'YY'+paymentModeName+'XX');  // Affiche le nom du mode de paiement
  
        // Mettre à jour l'état avec le nom du mode de paiement
        setPaymentMode(paymentModeName);
       /// setPaymentMode('Virement bancaire');
      }
    } catch (error) {
      console.error('Erreur lors de la récupération du mode de paiement:', error);
    }
  };
  
/*useEffect(() => {
  const paymentMode = await request.read({ entity: 'paymentmode', id });

    if (paymentMode) {
      const paymentModeName = paymentMode.name;  
      console.log('Nom du mode de paiement:', paymentModeName);  
      setPaymentMode(paymentModeName);  
    }
}, []);*/
  return (
    
    <>
      {/* Sélection du client avec AutoCompleteAsync */}
      <Form.Item
        label="Client"
        name="client"
        rules={[{ required: true, message: 'Veuillez sélectionner un client!' }]}
      >
        <AutoCompleteAsync
          entity={'client'}  // Entité clients pour récupérer les clients
          displayLabels={['name']}  // Affichage du nom dans la liste déroulante
          searchFields={'name'}  // Recherche par le nom du client
          redirectLabel={'Ajouter un nouveau client'}  // Lien pour ajouter un client si nécessaire
          withRedirect
          urlToRedirect={'/customer'}  // URL pour ajouter un nouveau client
          
        />
      </Form.Item>
      <Form.Item
  label="Numéro"
  name="number"
  initialValue={lastNumber}
  rules={[{ required: true, message: 'Veuillez entrer un numéro!' }]}
>        <Input type="number" />
</Form.Item>

      {/* Champ SIRET */}
      <Form.Item
        label="SIRET"
        name="siret"
        rules={[{ required: true, message: 'Veuillez entrer le SIRET!' }]}
      >
        <Input />
      </Form.Item>

      {/* Nom du représentant */}
      <Form.Item
        label="Nom du représentant"
        name="representativeName"
        rules={[{ required: true, message: 'Veuillez entrer le nom du représentant!' }]}
      >
        <Input />
      </Form.Item>

      {/* Sélection du type de contrat (Services) avec AutoCompleteAsync */}
      <Form.Item
        label="Type de contrat"
        name="serviceType"
        rules={[{ required: true, message: 'Veuillez sélectionner un type de contrat!' }]}
      >
        <Select onChange={handleServiceChange} 
               // value={field.value?.service || ''} // Liaison avec la valeur du service
                >
                <Select.Option value="⬇️ Selectionnez service ⬇️"
                >-- Selectionnez un service --</Select.Option>
                {servicesList.map((service) => (
                  <Select.Option key={service.label} value={service.label}>
                    {service.label}
                  </Select.Option>
                ))}
              </Select>
      </Form.Item>

      {/* Affichage automatique du taux journalier basé sur le service sélectionné */}
      <Form.Item label="Tarif Journalier" name="dailyRate" >
  <Input value={dailyRate} onChange={(e) => setDailyRate(e.target.value)} />
</Form.Item>


      {/* Nombre d'agents */}
      <Form.Item
        label="Nombre d'agents"
        name="numberOfAgents"
        rules={[{ required: true, message: 'Veuillez entrer le nombre d\'agents!' }]}
      >
        <Input type="number" />
      </Form.Item>

      {/* Mode de paiement */}
      <Form.Item
        label="Mode de paiement"
        name="paymentMode"
        rules={[{ required: true, message: 'Veuillez choisir un mode de paiement!' }]}
      >
        <AutoCompleteAsync
          entity="paymentmode"  // Entité pour récupérer les modes de paiement
          displayLabels={['name']}  // Affichage du nom du mode de paiement
          searchFields="name"  // Recherche par le nom du mode de paiement
          redirectLabel="Ajouter un nouveau mode de paiement"  // Lien pour ajouter un mode de paiement si nécessaire
          urlToRedirect="/paymentmode"  // URL pour ajouter un mode de paiement
          onChange={handlePaymentModeChange}  // Écouter le changement du mode de paiement
          //value={selectedPaymentMode}  // Ici tu passes l'ID directement
          />
      </Form.Item>

      {paymentMode === 'Virement bancaire' && (
        <>
          <Form.Item
            label="Nom de la Banque"
            name="banque"
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="RIB"
            name="rib"
          >
            <Input />
          </Form.Item>
        </>
      )}

      {/* Date de début du contrat */}
      <Form.Item
        label="Date de début"
        name="startDate"
        rules={[{ required: true, message: 'Veuillez choisir une date de début!' }]}
      >
        <DatePicker style={{ width: '100%' }} />
      </Form.Item>

      {/* Date de fin du contrat */}
      <Form.Item
        label="Date de fin"
        name="endDate"
        rules={[{ required: true, message: 'Veuillez choisir une date de fin!' }]}
      >
        <DatePicker style={{ width: '100%' }} />
      </Form.Item>

      {/* Statut du contrat */}
      <Form.Item
        label="Statut du contrat"
        name="status"
        initialValue="actif"
        rules={[{ required: true, message: 'Veuillez choisir un statut!' }]}
      >
        <Select>
          <Select.Option value="actif">Actif</Select.Option>
          <Select.Option value="suspendu">Suspendu</Select.Option>
          <Select.Option value="en_attente">En attente</Select.Option>
          <Select.Option value="resilie">Résilié</Select.Option>
        </Select>
      </Form.Item>

      
    </>
  );
}
