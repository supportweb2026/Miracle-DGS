import { useState, useEffect } from 'react';

import { useDispatch, useSelector } from 'react-redux';
import { crud } from '@/redux/crud/actions';
import { useCrudContext } from '@/context/crud';
import { selectCreatedItem } from '@/redux/crud/selectors';

import useLanguage from '@/locale/useLanguage';

import { Button, Form } from 'antd';
import Loading from '@/components/Loading';
import { request } from '@/request';
import { settingsAction } from '@/redux/settings/actions';

export default function CreateForm({ config, formElements, withUpload = false }) {
  
  console.log('fonction createForm...');
  let { entity } = config;
  const dispatch = useDispatch();
  const { isLoading, isSuccess } = useSelector(selectCreatedItem);
  const { crudContextAction } = useCrudContext();
  const { panel, collapsedBox, readBox } = crudContextAction;
  const [form] = Form.useForm();
  const translate = useLanguage();
    const [servicesList, setServicesList] = useState([]);
     const [dailyRate, setDailyRate] = useState(15); // L'état pour les services
    
  
  const onSubmit = (fieldsValue) => {
    // Manually trim values before submission
    console.log('fieldsValue=',fieldsValue);
    console.log('number fieldsvalues=',fieldsValue.number);
    //Incrémentation du numéro de contrat
    dispatch(
      settingsAction.update({
        entity: 'setting', 
        settingKey: 'last_contract_number', 
        jsonData: { settingValue: fieldsValue.number }, 
      })
    );
    if (fieldsValue.file && withUpload) {
      fieldsValue.file = fieldsValue.file[0].originFileObj;
    }

    // const trimmedValues = Object.keys(fieldsValue).reduce((acc, key) => {
    //   acc[key] = typeof fieldsValue[key] === 'string' ? fieldsValue[key].trim() : fieldsValue[key];
    //   return acc;
    // }, {});
  console.log('tu es dans create form ');
    dispatch(crud.create({ entity, jsonData: fieldsValue, withUpload }));
  };
 const fetchAllServices = async () => {
    console.log('fetchallservice tizi macadam createform');
    let allServices = [];
  
    try {
      console.log('appel request');
      const response = await request.list({ entity: 'service' });
      console.log('recu ^response');

      if (response.success && response.result && Array.isArray(response.result)) {
        allServices = response.result;
        console.log('recup sucess');
        console.log(allServices);
      } else {
        console.log("Aucun service trouvé.");
        return; // Sortir de la fonction si aucun service n'est trouvé
      }
  
      let servicesList = allServices.map(service => ({
        label: service.name,   
        value: service.tauxJournalier 
      }));
  
      console.log("Services sous forme de label-value:", servicesList);
  
      
  
      // Si vous voulez mettre à jour l'état service, faites-le aussi ici si nécessaire
      setServicesList(servicesList);
      console.log("Services sous forme de Map:", servicesList);
  
      // Retourner la Map des services
      return servicesList;
    } catch (error) {
      console.error("Erreur lors de la récupération des services :", error);
    }
  };

  useEffect(() => {
    // Appel fetchAllServices 
    const getServices = async () => {
      const result = await fetchAllServices();
      console.log('result createform:',result);
      if (result) {
        setServicesList(result); 
      }
    };
    getServices();
  }, []); 
  
  useEffect(() => {
    console.log('use effect entity:',entity);
    if (entity === 'contract') {
      console.log('nous somme dans le if contract dailyrate:',dailyRate);
      form.setFieldsValue({ dailyRate: dailyRate });
      
    }
  }, [dailyRate, entity, form]);

  // Exemple de fonction qui met à jour dailyRate (à utiliser dans ton Select par exemple)
  const handelValuesChange = (selectedValue) => {
    console.log('appel dans createform',entity,' services:',servicesList, 'selectedValue:',selectedValue);
    const label = typeof selectedValue === 'object' && selectedValue !== null
    ? selectedValue.serviceType 
    : selectedValue;
    const selectedService = servicesList.find(service => service.label === selectedValue.serviceType);
    //const selectedService = Object.values(servicesList.reduce((acc, { label, value }) => ({ ...acc, [label]: value }), {}))[servicesList.findIndex(serviceItem => serviceItem.label === service.service)];

    console.log('selectedService: createform', selectedService);
    console.log('createform select entity:', entity, 'srv:', selectedService);
    if (selectedService && entity === 'contract') {
      setDailyRate(selectedService.value);
      console.log('value dailyrate: createform', selectedService.value);
      form.setFieldsValue({ dailyRate });
    }
  };
  useEffect(() => {
    if (isSuccess) {
      readBox.open();
      collapsedBox.open();
      panel.open();
      form.resetFields();
      dispatch(crud.resetAction({ actionType: 'create' }));
      dispatch(crud.list({ entity }));
    }
  }, [isSuccess]);

  return (
    <Loading isLoading={isLoading}>
        <Form form={form} layout="vertical" onFinish={onSubmit} onValuesChange ={handelValuesChange} >
        {formElements}
        <Form.Item>
          <Button type="primary" htmlType="submit">
            {translate('Submit')}
          </Button>
        </Form.Item>
      </Form>
    </Loading>
  );
}
