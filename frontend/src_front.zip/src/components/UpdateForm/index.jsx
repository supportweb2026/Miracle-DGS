import { useEffect } from 'react';
import dayjs from 'dayjs';

import { useDispatch, useSelector } from 'react-redux';
import { crud } from '@/redux/crud/actions';
import { useCrudContext } from '@/context/crud';
import { selectUpdatedItem } from '@/redux/crud/selectors';
import { useState } from 'react';
//import { request } from '@/request';
import { useWatch } from 'antd/es/form/Form';
import { request } from '@/request';
import ContractForm from '@/forms/ContractForm';

import useLanguage from '@/locale/useLanguage';

import { Button, Form } from 'antd';
import Loading from '@/components/Loading';

export default function UpdateForm({ config, formElements, withUpload = false }) {
  let { entity } = config;
  const translate = useLanguage();
  const dispatch = useDispatch();
  const { current, isLoading, isSuccess } = useSelector(selectUpdatedItem);

  const { state, crudContextAction } = useCrudContext();
    const [servicesList, setServicesList] = useState([]);
    //Recuperation des services
    const fetchAllServices = async () => {
      console.log('fetchallservice tizi macadam createform');
      let allServices = [];
    
      try {
        console.log('appel request');
        const response = await request.list({ entity: 'service' });
        console.log('recu ^response');
  
        if (response.success && response.result && Array.isArray(response.result)) {
          allServices = response.result;
          console.log('recup sucess');
          console.log(allServices);
        } else {
          console.log("Aucun service trouvé.");
          return; // Sortir de la fonction si aucun service n'est trouvé
        }
    
        let servicesList = allServices.map(service => ({
          label: service.name,   
          value: service.tauxJournalier 
        }));
    
        console.log("Services sous forme de label-value: updateform", servicesList);
    
        
    
        // Si vous voulez mettre à jour l'état service, faites-le aussi ici si nécessaire
        setServicesList(servicesList);
        console.log("Services sous forme de Map updateform:", servicesList);
    
        // Retourner la Map des services
        return servicesList;
      } catch (error) {
        console.error("Erreur lors de la récupération des services :", error);
      }
    };


  
    useEffect(() => {
      // Appel fetchAllServices 
      const getServices = async () => {
        const result = await fetchAllServices();
        console.log('recuperation services cote updateform:',result);
        if (result) {
          setServicesList(result); 
        }
      };
      getServices();
    }, []); 

    
    const [clientsList, setClientsList] = useState([]);

    useEffect(() => {
      const fetchClients = async () => {
        try {
          const response = await request.list({ entity: 'client' });
          console.log('result client:', response.result);
          
          if (response.success && Array.isArray(response.result)) {
            // Transformer les clients en format {label, value}
            const formattedClients = response.result.map(client => ({
              label: client.name || client.company, // Utiliser le nom ou la société comme label
              value: client._id, // Utiliser l'ID comme value
              ...client // Garder les autres propriétés du client
            }));
            setClientsList(formattedClients);
          }
        } catch (error) {
          console.error('Erreur lors de la récupération des clients :', error);
        }
      };
    
      fetchClients();
    }, []);
    


    //console.log('coucou updateform:',servicesList);
    //Fin recuperation des services
  
  /////

  const { panel, collapsedBox, readBox } = crudContextAction;

  const showCurrentRecord = () => {
    readBox.open();
  };
  console.log('coucou');

  /////
  const [form] = Form.useForm();
const selectedClientId = useWatch('client', form);
//console.log('current.client._id=',current.client);
const [selectedClient, setSelectedClient] = useState(null);
const [selectedpaymentMode, setSelectedPaymentMode] = useState(null);
console.log('toto tata selectedClient=',selectedClient);

useEffect(() => {
  if (selectedClientId) {
    const client = clientsList.find((c) => c._id === selectedClientId);
    console.log('selectedClientId=',selectedClientId);
    if (client) {
      setSelectedClient(client.id); // on garde l'objet à part
      console.log('current client=',current.client);
      console.log('ensuite client selectionne=',client);
      console.log('Client complet sélectionné :', client);
    } else {
      console.error('Client non trouvé dans la liste.');
      setSelectedClient(null);
    }
  }
}, [selectedClientId, clientsList]);

//
const [paymentModes, setPaymentModes] = useState([]);

    useEffect(() => {
      const fetchPayment = async () => {
        try {
          const response = await request.list({ entity: 'paymentmode' });
          console.log('result paymentModes:', response.result);
          
          if (response.success && Array.isArray(response.result)) {
            // Garder uniquement les objets clients, sans formatage "label" et "value"
            setPaymentModes(response.result);  // Ici on garde l'objet complet client
          }
        } catch (error) {
          console.error('Erreur lors de la récupération des clients :', error);
        }
      };
    
      fetchPayment();
    }, []);
    
    //
  const selectedPaymentMode = useWatch('paymentMode', form);
  useEffect(() => {
    //console.log('selectedPaymentMode]=',selectedPaymentMode);

    if (selectedPaymentMode) {
      const paymentMode = paymentModes.find((c) => c._id === selectedPaymentMode);
if(paymentMode) {
      setSelectedPaymentMode(paymentMode);
  console.log('oui selectedPaymentMode=',paymentMode);
}
    
  //form.resetFields();

  //form.setFieldsValue({ paymenstMode:  selectedPaymentMode });
  

    }
}, [selectedPaymentMode,paymentModes]);


  const onSubmit = (fieldsValue) => {
    const id = current._id;

    if (fieldsValue.file && withUpload) {
      fieldsValue.file = fieldsValue.file[0].originFileObj;
    }
    // const trimmedValues = Object.keys(fieldsValue).reduce((acc, key) => {
    //   acc[key] = typeof fieldsValue[key] === 'string' ? fieldsValue[key].trim() : fieldsValue[key];
    //   return acc;
    // }, {});
    dispatch(crud.update({ entity, id, jsonData: fieldsValue, withUpload }));
  };

  const selectedServiceType = useWatch('serviceType', form);
  useEffect(() => {
    console.log('on est dans usewatch');
    console.log('selectedServiceType tzi=',selectedServiceType);
    console.log('servicesList=',servicesList);

    if (selectedServiceType && servicesList.length > 0) {
      const selected = servicesList.find(s => s.label === selectedServiceType);
      if (selected) {
        form.setFieldsValue({ dailyRate: selected.value });
      }
    }
  }, [selectedServiceType]);
  useEffect(() => {
    console.log('Current a changé:', current);
    if (current) {
      console.log('coucou tizi real niggaz');
      let newValues = { ...current };
      console.log('newvalues',newValues);

      if (newValues.birthday) {
        newValues = {
          ...newValues,
          birthday: dayjs(newValues['birthday']).format('YYYY-MM-DDTHH:mm:ss.SSSZ'),
        };
      }
      if (newValues.date) {
        newValues = {
          ...newValues,
          date: dayjs(newValues['date']).format('YYYY-MM-DDTHH:mm:ss.SSSZ'),
        };
      }
      if (newValues.expiredDate) {
        newValues = {
          ...newValues,
          expiredDate: dayjs(newValues['expiredDate']).format('YYYY-MM-DDTHH:mm:ss.SSSZ'),
        };
      }
      if (newValues.created) {
        newValues = {
          ...newValues,
          created: dayjs(newValues['created']).format('YYYY-MM-DDTHH:mm:ss.SSSZ'),
        };
      }
      if (newValues.updated) {
        newValues = {
          ...newValues,
          updated: dayjs(newValues['updated']).format('YYYY-MM-DDTHH:mm:ss.SSSZ'),
        };
      }
      if (newValues.startDate) {
        newValues.startDate = dayjs(newValues.startDate);
      }
      if (newValues.endDate) {
        newValues.endDate = dayjs(newValues.endDate);
      }
      if (newValues.client ) {
        console.log('newValues.client)=',newValues.client);
       // console.log('newValues.client id)=',newValues.client._id);
       // console.log('zoumeye selectedClientId=',selectedClientId);
          //  if(selectedClient) {
          console.log('eh oui selectedClientId=',selectedClientId);
          newValues.client = ''; 
           // }
          
      }
      if(newValues.paymentMode) {
        console.log('newValues paymentmode:',newValues.paymentMode);
        console.log('newValues paymentmode id:',newValues.paymentMode.id);

        newValues.paymentMode = selectedPaymentMode;
      }
      
   
   
      if (newValues.serviceType) {

        console.log('serviceType wina=', newValues.serviceType);

        // Chercher le service correspondant dans servicesList
        //const selectedService = servicesList.find(service => service.label === newValues.serviceType);
  
        // Mettre à jour dailyRate avec la valeur du service sélectionné
        //if (selectedService) {
         // newValues.dailyRate = selectedService.value;
         // console.log('dailyRate mis à jour:', selectedService.value);
       // }
      }
      
     // form.resetFields();
      form.setFieldsValue(newValues);
    }
  }, [current]);

  useEffect(() => {
    if (isSuccess) {
      readBox.open();
      collapsedBox.open();
      panel.open();
      form.resetFields();
      dispatch(crud.resetAction({ actionType: 'update' }));
      dispatch(crud.list({ entity }));
    }
  }, [isSuccess]);

  const { isEditBoxOpen } = state;

  const show = isEditBoxOpen ? { display: 'block', opacity: 1 } : { display: 'none', opacity: 0 };
  console.log('isEditBoxOpen =', isEditBoxOpen);
  console.log('formElements =', formElements);
  console.log('isLoading =', isLoading);

  return (
    <div style={show}>
      <Loading isLoading={isLoading}>
        <Form form={form} layout="vertical" onFinish={onSubmit}>
          {formElements}

          <Form.Item
            style={{
              display: 'inline-block',
              paddingRight: '5px',
            }}
          >
            <Button type="primary" htmlType="submit">
              {translate('Save')}
            </Button>
          </Form.Item>
          <Form.Item
            style={{
              display: 'inline-block',
              paddingLeft: '5px',
            }}
          >
            <Button onClick={showCurrentRecord}>{translate('Cancel')}</Button>
          </Form.Item>
        </Form>
      </Loading>
    </div>
  );
}
