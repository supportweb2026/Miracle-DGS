import React, { useEffect } from 'react';
import { Form, Input, DatePicker, Select, InputNumber, Button } from 'antd';
import dayjs from 'dayjs';
import { useDispatch, useSelector } from 'react-redux';
import { crud } from '@/redux/crud/actions';
import { selectUpdatedItem } from '@/redux/crud/selectors';
import { useCrudContext } from '@/context/crud';
import useLanguage from '@/locale/useLanguage';
import Loading from '@/components/Loading';

const { Option } = Select;

export default function UpdateContractForm({ isUpdateForm }) {
  const translate = useLanguage();
  const dispatch = useDispatch();
  const { current, isLoading, isSuccess } = useSelector(selectUpdatedItem);
  const { state, crudContextAction } = useCrudContext();
  const { readBox, collapsedBox, panel } = crudContextAction;

  const [form] = Form.useForm();
  const entity = 'contract';

  const onSubmit = (values) => {
    const id = current._id;

    // Formatage des dates en ISO
    const formattedValues = {
      ...values,
      startDate: values.startDate?.toISOString(),
      endDate: values.endDate?.toISOString(),
    };

    dispatch(crud.update({ entity, id, jsonData: formattedValues }));
  };

  useEffect(() => {
    if (current) {
      const initialValues = {
        ...current,
        startDate: current.startDate ? dayjs(current.startDate) : null,
        endDate: current.endDate ? dayjs(current.endDate) : null,
      };

      form.setFieldsValue(initialValues);
    }
  }, [current]);

  useEffect(() => {
    if (isSuccess) {
      form.resetFields();
      readBox.open();
      collapsedBox.open();
      panel.open();
      dispatch(crud.resetAction({ actionType: 'update' }));
      dispatch(crud.list({ entity }));
    }
  }, [isSuccess]);

  const show = state.isEditBoxOpen ? { display: 'block', opacity: 1 } : { display: 'none', opacity: 0 };

  return (
    <div style={show}>
      <Loading isLoading={isLoading}>
        <Form form={form} layout="vertical" onFinish={onSubmit}>
          <Form.Item name="number" label={translate('Number')} rules={[{ required: true }]}>
            <Input />
          </Form.Item>

          <Form.Item name={['client', '_id']} label={translate('Client')} rules={[{ required: true }]}>
            <Select placeholder="Sélectionner un client">
              {/* Tu peux remplacer ça par une map dynamique sur ta liste de clients */}
              <Option value="1">Client A</Option>
              <Option value="2">Client B</Option>
            </Select>
          </Form.Item>

          <Form.Item name="serviceType" label={translate('Type de contrat')}>
            <Input />
          </Form.Item>

          <Form.Item name="startDate" label={translate('Date de début')}>
            <DatePicker format="DD/MM/YYYY" />
          </Form.Item>

          <Form.Item name="endDate" label={translate('Date de fin')}>
            <DatePicker format="DD/MM/YYYY" />
          </Form.Item>

          <Form.Item name="status" label={translate('Statut')}>
            <Select>
              <Option value="actif">Actif</Option>
              <Option value="suspendu">Suspendu</Option>
              <Option value="terminé">Terminé</Option>
            </Select>
          </Form.Item>

          <Form.Item name="siret" label="SIRET">
            <Input />
          </Form.Item>

          <Form.Item name="representativeName" label="Nom du représentant">
            <Input />
          </Form.Item>

          <Form.Item name="dailyRate" label="Taux journalier">
            <InputNumber min={0} style={{ width: '100%' }} />
          </Form.Item>

          <Form.Item name="numberOfAgents" label="Nombre d'agents">
            <InputNumber min={1} style={{ width: '100%' }} />
          </Form.Item>

          <Form.Item name={['paymentMode', '_id']} label="Mode de paiement">
            <Select>
              <Option value="1">Virement bancaire</Option>
              <Option value="2">Chèque</Option>
              <Option value="3">Espèces</Option>
            </Select>
          </Form.Item>

          <Form.Item shouldUpdate={(prev, curr) => prev.paymentMode !== curr.paymentMode}>
            {() => {
              const paymentMode = form.getFieldValue(['paymentMode', '_id']);
              const isVirement = paymentMode === '1'; // Id du virement bancaire
              return isVirement && (
                <>
                  <Form.Item name="rib" label="RIB">
                    <Input />
                  </Form.Item>
                  <Form.Item name="banque" label="Banque">
                    <Input />
                  </Form.Item>
                </>
              );
            }}
          </Form.Item>

          <Form.Item>
            <Button type="primary" htmlType="submit">
              {translate('Save')}
            </Button>
            <Button onClick={readBox.open} style={{ marginLeft: 8 }}>
              {translate('Cancel')}
            </Button>
          </Form.Item>
        </Form>
      </Loading>
    </div>
  );
}
