import { useEffect, useState } from 'react';
import { Row, Col } from 'antd';
import { useSelector } from 'react-redux';

import dayjs from 'dayjs';
import { dataForRead } from '@/utils/dataStructure';

import { useCrudContext } from '@/context/crud';
import { selectCurrentItem } from '@/redux/crud/selectors';
import { valueByString } from '@/utils/helpers';

import useLanguage from '@/locale/useLanguage';
import { useDate } from '@/settings';

export default function ReadItem({ config }) {
  const { dateFormat } = useDate();
  let { readColumns, fields } = config;
  const translate = useLanguage();
  const { result: currentResult } = useSelector(selectCurrentItem);
  const { state } = useCrudContext();
  const { isReadBoxOpen } = state;
  const [listState, setListState] = useState([]);

  if (fields) readColumns = [...dataForRead({ fields: fields, translate: translate })];
  
  useEffect(() => {
    const list = [];
    readColumns.map((props) => {
      console.log('props:',props);
      const propsKey = props.dataIndex;
      const propsTitle = props.title;
      //const isDate = props.isDate || false;
      let value = valueByString(currentResult, propsKey);
      console.log('value valeur:',value);
      //value = isDate ? dayjs(value).format(dateFormat) : value;
      console.log('La valeur est un objet pour', propsKey, ':', JSON.stringify(value, null, 2));
      console.log(`Type de value pour ${propsKey}:`, typeof value, value);

      if (props.render && typeof props.render === 'function') {
        console.log(`Valeur avant render (${propsKey}):`, value);
      
        // Si value est une string qui représente un JSON, on la reconvertit en objet
        if (typeof value === 'string' && value.startsWith('{') && value.endsWith('}')) {
          try {
            value = JSON.parse(value);
          } catch (error) {
            console.error(`Erreur lors du parsing de ${propsKey}:`, error);
          }
        }
      
        //value = props.render(value, currentResult);
        value = value != null ? props.render(value, currentResult) : 'N/A';
       
       /*value = value != null && typeof props.render === 'function'
       ? props.render(value, currentResult)
       : 'N/A';*/
   

     
        console.log(`Valeur après render (${propsKey}):`, value);
      }
      
      if (typeof value === 'object' && value !== null) {
        console.warn(`Attention: ${propsKey} est encore un objet, extraction de ses champs...`);
        
        // EXTRAIRE "name" par défaut si disponible
        value = value.name ?? JSON.stringify(value); // Fallback en JSON
      }
      
      

      list.push({ propsKey, label: propsTitle, value: value });
    });
    setListState(list);
  }, [currentResult]);

  const show = isReadBoxOpen ? { display: 'block', opacity: 1 } : { display: 'none', opacity: 0 };

  const itemsList = listState.map((item) => {
    return (
      <Row key={item.propsKey} gutter={12}>
        <Col className="gutter-row" span={8}>
          <p>{item.label}</p>
        </Col>
        <Col className="gutter-row" span={2}>
          <p> : </p>
        </Col>
        <Col className="gutter-row" span={14}>
          <p>{item.value}</p>
        </Col>
      </Row>
    );
  });

  return <div style={show}>{itemsList}</div>;
}
