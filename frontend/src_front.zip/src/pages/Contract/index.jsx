import React from 'react';
import useLanguage from '@/locale/useLanguage';
import CrudModule from '@/modules/CrudModule/CrudModule';
import ContractForm from '@/forms/ContractForm'; 
import { ConfigProvider, Button  } from 'antd';
import { selectCurrentItem } from '@/redux/erp/selectors'; 
import {useSelector} from 'react-redux';
import locale from 'antd/locale/fr_FR';
import dayjs from 'dayjs';
import 'dayjs/locale/fr';
dayjs.locale('fr');
import { useState, useEffect, useRef } from 'react';

export default function Contract() {
  //const [servicesList, setServicesList] = useState([]);
  //console.log('seviceList de index page contract:',servicesList);
  const translate = useLanguage();
  const entity = 'contract'; 
  const { result: currentErp } = useSelector(selectCurrentItem);
console.log('result:',currentErp);
  // Configuration de la recherche
  const searchConfig = {
    displayLabels: ['name', 'client'],  
    searchFields: 'name',  // Recherche par le nom de la dépense
    outputValue: '_id',  // Id à récupérer lors de la recherche
  };

  const deleteModalLabels = ['number', 'client.name'];

  const readColumns = [
    {
      title: translate('Number'),
      dataIndex: 'number',
      sorter: (a, b) => a.number - b.number,
    },
    
    {
      title: translate('Client'),
      dataIndex: 'client', 
      render: (client) => {
        return client && typeof client === 'object' ? client.name : 'N/A';
      }
    },
    {
      title: translate('Type de contrat'),
      dataIndex: 'serviceType',  
    },
    {
      title: translate('Date de début'),
      dataIndex: 'startDate',  
      render: (startDate) => dayjs(startDate).format('DD/MM/YYYY'), 
    },
    {
      title: translate('Date de fin'),
      dataIndex: 'endDate',  
      render: (endDate) => dayjs(endDate).format('DD/MM/YYYY'), 
      
    },
    {
      title: translate('Statut'),
      dataIndex: 'status',  
    },
    {
      title: translate('Siret'),
      dataIndex: 'siret', 
    },
    {
      title: translate('Nom du représentant'),
      dataIndex: 'representativeName',  
    },
    {
      title: translate('Taux journalier'),
      dataIndex: 'dailyRate',  
    },
    {
      title: translate('Nombre d\'agents'),
      dataIndex: 'numberOfAgents',  
    },
    {
      title: translate('Mode de paiement'),
      dataIndex: 'paymentMode',
      render: (paymentMode) => {
        console.log('paymentMode reçu dans render:', paymentMode);
        return paymentMode && typeof paymentMode === 'object' ? paymentMode.name : 'N/A';
      }
    },
    {
      title: translate('RIB'),
      dataIndex: 'rib',  
      render: (rib, record) => {
        const paymentModeName = record?.paymentMode?.name || ''; // on force une valeur par défaut
        return paymentModeName === 'Virement bancaire' ? rib : 'N/A';
      }
    },
    {
      title: translate('Banque'),
      dataIndex: 'banque',  
      render: (banque, record) => (record?.paymentMode?.name === 'Virement bancaire' ? banque : 'N/A'),  // Afficher Banque si paiement est 'Virement bancaire'
    },
  ];

  const dataTableColumns = [
    {
      title: translate('Number'),
      dataIndex: 'number',
      sorter: (a, b) => a.number - b.number,
    },
    {
      title: translate('Client'),
      dataIndex: ['client', 'name'],  
    render: (text, record) => (
      <span>{record.client?.name || 'Nom du client non défini'}</span>  
    ),
    sorter: (a, b) => {
      const nameA = a.client?.name?.toLowerCase() || '';
      const nameB = b.client?.name?.toLowerCase() || '';
      return nameA.localeCompare(nameB);
    },
    },
    {
      title: translate('Type de contrat'),
      dataIndex: 'serviceType',
      sorter: (a, b) => a.contractType.localeCompare(b.contractType),
    },
    {
      title: translate('Date de début'),
      dataIndex: 'startDate',
      render: (startDate) => dayjs(startDate).format('DD/MM/YYYY'),
      sorter: (a, b) => new Date(a.startDate) - new Date(b.startDate),
    },
    {
      title: translate('Date de fin'),
      dataIndex: 'endDate',
      render: (endDate) => dayjs(endDate).format('DD/MM/YYYY'),
      sorter: (a, b) => new Date(a.endDate) - new Date(b.endDate),
    },
    {
      title: translate('Statut'),
      dataIndex: 'status',
      sorter: (a, b) => a.status.localeCompare(b.status),
    },
  ];

  const Labels = {
    PANEL_TITLE: translate('Contrats'),  
    DATATABLE_TITLE: 'Liste des Contrats',  
    ADD_NEW_ENTITY: 'Ajouter un nouveau contrat',  
    ENTITY_NAME: translate('contract'),  
  };

  const configPage = {
    entity,
    ...Labels,
  };

  const config = {
    ...configPage,
    readColumns,
    dataTableColumns,
    searchConfig,
    deleteModalLabels,
  };

  return (
    <ConfigProvider locale={locale}>
      <CrudModule
        createForm={<ContractForm />}  
        updateForm ={<ContractForm isUpdateForm={true} />}  
        config={config}  
      />
      
    </ConfigProvider>
  );
  
}
