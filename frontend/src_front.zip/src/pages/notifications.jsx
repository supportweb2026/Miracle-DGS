import React, { useState, useEffect } from 'react';
import { Button } from 'antd';
import { DeleteOutlined, ReloadOutlined } from '@ant-design/icons';  
import { useSelector } from 'react-redux';
import { selectCurrentAdmin } from '@/redux/auth/selectors';  
import { request } from '@/request'; 

//const { exec } = require('child_process');
//Fonction Bandeau

function GlobalNotificationBanner({ message }) {
  const [show, setShow] = useState(!!message);

  useEffect(() => {
    if (message) {
      setShow(true);
      const timer = setTimeout(() => setShow(false), 10000); // 10 sec affichage
      return () => clearTimeout(timer);
    }
  }, [message]);

  if (!show) return null;

  return (
    <div className="fixed bottom-4 right-0 w-full z-50 pointer-events-none">
      <div className="mx-auto max-w-xl bg-blue-600 text-white py-2 px-4 rounded shadow animate-marquee">
        🔔 {message}
      </div>

      <style jsx>{`
        .animate-marquee {
          animation: scroll-left 10s linear infinite;
          white-space: nowrap;
        }
        @keyframes scroll-left {
          from {
            transform: translateX(100%);
          }
          to {
            transform: translateX(-100%);
          }
        }
      `}</style>
    </div>
  );
};

//Fin
const NotificationsPage = () => {
  const [notifications, setNotifications] = useState([]);  
  const [selectedNotificationId, setSelectedNotificationId] = useState(null);

  const currentAdmin = useSelector(selectCurrentAdmin);
  console.log('currentAdmin=', currentAdmin._id);

  const fetchNotifications = async () => {
    if (currentAdmin) {
      console.log('oui currentAdmin',);
      try {
        const response = await request.listAll({
          entity: 'notification',
          options: {
            user: currentAdmin._id, 
          }
        });
        console.log('response=', response);
        const fetchedNotifications = Array.isArray(response.result) ? response.result : [];
        console.log('fetchedNotifications=', fetchedNotifications);
        const notificationsForCurrentAdmin = fetchedNotifications
          .map(notification => {
            console.log('user=', notification.user); // Vérif valeurs de "user" pour le débogageiez les
            console.log('currentAdmin:', currentAdmin._id);
            console.log('user=currentAdmin?', notification.user === currentAdmin._id);
            return notification;
          })
          .filter(notification => notification.user === currentAdmin._id);
        console.log('notificationsForCurrentAdmin=', notificationsForCurrentAdmin);
        setNotifications(notificationsForCurrentAdmin); 
      } catch (error) {
        console.error('Erreur lors de la récupération des notifications:', error);
        setNotifications([]);  // En cas d'erreur, on vide les notifications
      }
    }
  };

  
  useEffect(() => {
    console.log('use effec fetch');
    fetchNotifications();
  }, [currentAdmin]);

  // Fonction pour supprimer une notification
  const deleteNotification = async (id) => {
    
    
    console.log('appel fonction delete notification id',id);
    try {
      const response = await request.delete({
        entity: 'notification', 
        id,  
      });
    
      setNotifications(notifications.filter(notification => notification._id !== id));

    } catch (error) {
      console.error('Erreur lors de la mise à jour de la notification:', error);
    }
  };
  

  // Fonction pour gérer le clic sur une notification et défiler jusqu'à l'élément
  // Fonction pour gérer le clic sur une notification et défiler jusqu'à l'élément
const handleNotificationClick = (id) => {
  console.log('iddddd=',id);
  // Si la notification est déjà sélectionnée, la désélectionner
  setSelectedNotificationId(prevId => prevId === id ? null : id);

  // Faire défiler la page jusqu'à la notification sélectionnée
  const element = document.getElementById(`notif-${id}`);
  console.log('elementtttt=',element);
  if (element) {
    element.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
};
const openPreFilledEmail = (email, name) => {
  const subject = encodeURIComponent("Rappel : Expiration de votre contrat");
  const body = encodeURIComponent(`Bonjour ${name},

Nous souhaitons vous rappeler que votre contrat arrive bientôt à expiration.
N'hésitez pas à nous contacter pour le renouveler et éviter toute interruption de service.

Cordialement,
Votre équipe DGS
Centre médicaux
Libreville, Gabon
dgsgabon2.0@gmail.com
+247 074 80 87 81
www.dgs-gabon.com`);

  const mailtoLink = `mailto:${email}?subject=${subject}&body=${body}`;
  window.location.href = mailtoLink;
};
const openInvoiceReminderEmail = (email, name, invoiceNumber, expiredDate) => {
  const subject = encodeURIComponent("Rappel : Facture impayée - Relance de paiement");
  console.log('expiredDate=',expiredDate);
  //const formattedExpiredDate = new Date(expiredDate).toLocaleDateString('fr-FR');
  console.log('formattedExpiredDate=',expiredDate);

  const body = encodeURIComponent(`Bonjour ${name},

Nous souhaitons vous rappeler que la facture n°${invoiceNumber} est arrivée à échéance le ${expiredDate}.
Nous vous prions de bien vouloir procéder au règlement dans les plus brefs délais afin d'éviter toute interruption de service.

Pour toute question, n'hésitez pas à nous contacter.

Cordialement,
Votre équipe DGS
Centre médicaux
Libreville, Gabon
dgsgabon2.0@gmail.com
+247 074 80 87 81
www.dgs-gabon.com`);

  const mailtoLink = `mailto:${email}?subject=${subject}&body=${body}`;
  window.location.href = mailtoLink;
};




  // Fonction de relance pour la notification (vous pouvez l'adapter à vos besoins)
  const relaunchNotification = async  (id,type,idNotification) => {
    console.log(`Relancer la notification avec l'ID: ${id} et le type ${type}`);
    console.log('idNotification=',idNotification);
    if(type=='Contract') {
      console.log('On est dans contrat');
      const response = await request.read({
        entity: 'contract',
        id: id,
      });
  
      const client = response?.result?.client;
      console.log('Client Email :', client.email);
      console.log('Client firstname :', client.name);

      //envoie mail
      const email = client.email;
      const name = client.name;
      console.log('...email name front:',email,name);
      openPreFilledEmail(email,name);
      //const responseScript = await request.executePowerShellScript({ email, name });
      /* let powershellScriptPath = 'C:\\Users\\ztoure\\WORKSPACE\\idurar-erp-crm\\backend\\src\\scripts\\sendrelancecontract.ps1';
      console.log('path sendinvoice:',powershellScriptPath);
      const command = `powershell -Command "& { ${powershellScriptPath} -email '${email}' -firstName '${name}' }"`;
console.log('Exécution de la commande PowerShell:', command);

exec(command, (error, stdout, stderr) => {
  if (error) {
    console.error(`Erreur lors de l'exécution du script PowerShell : ${error.message}`);
    return;
  }

  if (stderr) {
    console.error(`Erreur PowerShell : ${stderr}`);
    return;
  }

  console.log(`Résultat PowerShell : ${stdout}`);
});*/
    }
    else if(type=='Invoice') {
      console.log('On est dans contrat');
      const response = await request.read({
        entity: 'invoice',
        id: id,
      });
  console.log('response invoice=',response);
      const client = response?.result?.client;
      console.log('Client Email :', client.email);
      console.log('Client firstname :', client.name);

      //envoie mail
      const email = client.email;
      const name = client.name;
      const invoiceNumber = response.result.number;

      const expiredDate = new Date(response.result.expiredDate).toLocaleDateString('fr-FR');
      console.log('...email name front:',email,name,invoiceNumber,expiredDate);
      openInvoiceReminderEmail(email,name,invoiceNumber,expiredDate);
    }
    const notifs = await request.listAll({
      entity: 'notification',
      });
      //recup des notfifs ayant l'id correspondant après relance
      const filteredNotifs = (notifs?.result || []).filter(
        notif => notif.relatedId === id
      );
    //console.log('filteredNotifs=',filteredNotifs);
    
    
    //console.log('notifs =',notifs);
   // console.log('idNotification=',idNotification);
    //Suppression des notifications après la relance effectuée
    await Promise.all(
      filteredNotifs.map(async (notif) => {
        try {
          await request.delete({
            entity: 'notification',
            id: notif._id,
          });
          console.log(`Supprimé : ${notif._id}`);
        } catch (error) {
          console.error(`Erreur suppression ${notif._id} :`, error);
        }
      })
    );
  };

  return (
    <>
    <GlobalNotificationBanner message="Une relance a été effectuée par..." type="info" />
    <div style={styles.pageContainer}>
      <div style={styles.header}>
        <p style={styles.title}>Notifications</p>
        <Button type="text" shape="circle" style={styles.clearBtn}>
          <DeleteOutlined />
        </Button>
      </div>
      <div style={styles.notificationList}>
        {notifications.length > 0 ? (
          notifications.map((notification) => (
            <div
              id={`notif-${notification._id}`} // Ajoute un id unique pour chaque notification
              key={notification._id}
              style={styles.notificationItem}
              onClick={() => handleNotificationClick(notification._id)}
            >
              <Button type="text" style={styles.notificationBtn}>
                <span>{notification.message}</span>
              </Button>
              <Button
                type="text"
                style={styles.deleteBtn}
                shape="circle"
                onClick={(e) => {
                  e.stopPropagation(); // Empêche le clic de déclencher le défilement
                  deleteNotification(notification._id); // Suppression de la notification
                }}
              >
                <DeleteOutlined />
              </Button>
              {selectedNotificationId === notification._id && (
                <div style={styles.notificationDetail}>
                  <p>{notification.detail}</p>
                  <Button
                    type="primary"
                    style={styles.relaunchBtn}
                    onClick={(e) => {
                      e.stopPropagation();  // Empêche le clic de déclencher le défilement
                      relaunchNotification(notification.relatedId, notification.relatedType,notification._id); // Relance la notification
                    }}
                  >
                    <ReloadOutlined /> Relancer
                  </Button>
                </div>
              )}
            </div>
          ))
        ) : (
          <p>Aucune notification disponible.</p>  // Message à afficher si aucune notification n'est disponible
        )}
      </div>
    </div>
    </>
  );
  
};

// Styles object
const styles = {
  pageContainer: {
    padding: '20px',
    backgroundColor: '#f5f5f5',
    minHeight: '100vh',
  },
  header: {
    display: 'flex',
    alignItems: 'center',
    marginBottom: '20px',
    backgroundColor: '#fff',
    padding: '10px',
    borderRadius: '8px',
    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
  },
  title: {
    marginLeft: '10px',
    fontSize: '24px',
    color: '#333',
    fontWeight: 'bold',
  },
  clearBtn: {
    marginLeft: 'auto',
    fontSize: '20px',
    color: '#ff4d4f',
  },
  notificationList: {
    marginTop: '20px',
    backgroundColor: '#ffffff',
    borderRadius: '8px',
    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
  },
  notificationItem: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: '10px 20px',
    borderBottom: '1px solid #f0f0f0',
    cursor: 'pointer',
    alignItems: 'center', // Pour centrer le contenu sur l'axe vertical
  },
  notificationBtn: {
    fontSize: '16px',
    color: '#333',
    flex: 1,
    textAlign: 'left',
  },
  deleteBtn: {
    fontSize: '18px',
    color: '#ff4d4f',
  },
  notificationDetail: {
    marginTop: '10px',
    padding: '10px 20px', // Padding ajusté pour plus de lisibilité
    backgroundColor: '#f9f9f9',
    borderRadius: '8px',
    fontSize: '14px',
    color: '#555',
    width: '100%', // Pour que le texte prenne toute la largeur disponible
    display: 'block', // Force le texte à occuper une nouvelle ligne
    marginLeft: 0, // Aucune marge à gauche pour aligner le texte
    paddingLeft: '20px', // Assurer que l'alignement commence sous le texte de la notification
  },
  relaunchBtn: {
    marginTop: '10px',
    backgroundColor: '#4CAF50', // Une couleur verte pour le bouton de relance
    color: 'white',
    borderRadius: '4px',
    padding: '5px 10px',
  },
};

export default NotificationsPage;
