import React from 'react';
import useLanguage from '@/locale/useLanguage';
import CrudModule from '@/modules/CrudModule/CrudModule';
import { ConfigProvider } from 'antd';  // Importer ConfigProvider
import locale from 'antd/locale/fr_FR';  // Locale française
import ServiceForm from '@/forms/ServiceForm';  

export default function Service() {
  const translate = useLanguage();
  const entity = 'service'; // L'entité est le "service"

  // Configuration pour la recherche
  const searchConfig = {
    displayLabels: ['name', 'description'],  // Champs à afficher lors de la recherche
    searchFields: 'name',  // Recherche par nom de service
    outputValue: '_id',  // Id à récupérer lors de la recherche
  };

  // Labels pour la modal de suppression
  const deleteModalLabels = ['name'];  // Affiche le nom du service dans la modal de suppression

  // Colonnes de lecture (détail des services)
  const readColumns = [
    {
      title: translate('Nom'),
      dataIndex: 'name',  // Nom du service
    },
    {
      title: translate('Description'),
      dataIndex: 'description',  // Description du service
    },
    {
      title: translate('Taux Journalier'),
      dataIndex: 'tauxJournalier',  // Taux journalier du service
    },
    {
      title: translate('Devise'),
      dataIndex: 'currency',  // Devise du service
    },
  ];

  // Colonnes principales pour afficher les services
  const dataTableColumns = [
    {
      title: translate('Nom'),
      dataIndex: 'name',
      sorter: (a, b) => a.name.localeCompare(b.name),
    },
    {
      title: translate('Description'),
      dataIndex: 'description',
      sorter: (a, b) => a.description.localeCompare(b.description),
    },
    {
      title: translate('Taux Journalier'),
      dataIndex: 'tauxJournalier',
      sorter: (a, b) => a.tauxJournalier - b.tauxJournalier,
    },
    {
      title: translate('Devise'),
      dataIndex: 'currency',
      sorter: (a, b) => a.currency.localeCompare(b.currency),
    },
  ];

  // Labels pour l'interface utilisateur
  const Labels = {
    PANEL_TITLE: translate('services'),  // Titre du panneau pour "Services"
    DATATABLE_TITLE: translate('Liste des services'),  // Liste des services
    ADD_NEW_ENTITY: translate('Ajouter un service'),  // Libellé pour ajouter un service
    ENTITY_NAME: translate('service'),  // Nom de l'entité "Service"
  };

  // Configuration de la page avec les labels
  const configPage = {
    entity,
    ...Labels,
  };

  // Configuration finale pour le CRUD
  const config = {
    ...configPage,
    readColumns,
    dataTableColumns,
    searchConfig,
    deleteModalLabels,
  };

  return (
    <ConfigProvider locale={locale}>
      <CrudModule
        createForm={<ServiceForm />}  // Formulaire pour créer un service
        updateForm={<ServiceForm isUpdateForm={true} />}  // Formulaire pour mettre à jour un service
        config={config}
      />
    </ConfigProvider>
  );
}
