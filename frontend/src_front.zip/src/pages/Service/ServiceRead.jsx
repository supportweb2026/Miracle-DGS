import useLanguage from '@/locale/useLanguage';  // Utilisation de la fonction de traduction
import ReadServiceModule from '@/modules/ServiceModule/ReadServiceModule';  // Module pour la lecture des services

export default function ServiceRead() {
    console.log('ServiceRead...');
  const entity = 'service';  // Définir l'entité comme 'service'
  const translate = useLanguage();  // Fonction pour obtenir les traductions dynamiques
  const Labels = {
    PANEL_TITLE: translate('service'),  // Titre du panneau pour le service
    DATATABLE_TITLE: translate('service_list'),  // Titre pour la liste des services
    ADD_NEW_ENTITY: translate('add_new_service'),  // Label pour ajouter un nouveau service
    ENTITY_NAME: translate('service'),  // Nom de l'entité

    VIEW_ENTITY: translate('view_service'),  // Label pour la vue d'un service
  };

  // Configuration de la page
  const configPage = {
    entity,
    ...Labels,  // Ajouter les labels à la configuration
  };

  return <ReadServiceModule config={configPage} />;  // Rendu du module de lecture avec la configuration
}
