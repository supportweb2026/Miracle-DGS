import useLanguage from '@/locale/useLanguage';  // Utilisation de la fonction de traduction
import UpdateServiceModule from '@/modules/ServiceModule/UpdateServiceModule';  // Module pour la mise à jour des services

export default function ServiceUpdate() {
  const entity = 'service';  // Définir l'entité comme 'service'
  const translate = useLanguage();  // Fonction pour obtenir les traductions dynamiques
  const Labels = {
    PANEL_TITLE: translate('service'),  // Titre du panneau pour le service
    DATATABLE_TITLE: translate('service_list'),  // Titre pour la liste des services
    ADD_NEW_ENTITY: translate('add_new_service'),  // Label pour ajouter un nouveau service
    ENTITY_NAME: translate('service'),  // Nom de l'entité

    VIEW_ENTITY: translate('view_service'),  // Label pour "Record" au lieu de "View"
  };

  // Configuration de la page
  const configPage = {
    entity,
    ...Labels,  // Ajouter les labels à la configuration
  };

  return <UpdateServiceModule config={configPage} />;  // Rendu du module de mise à jour avec la configuration
}
