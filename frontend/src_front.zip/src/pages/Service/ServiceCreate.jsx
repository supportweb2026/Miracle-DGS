import useLanguage from '@/locale/useLanguage';  // Utilisation de la traduction
import CreateServiceModule from '@/modules/ServiceModule/CreateServiceModule';  // Module pour la création de service

export default function ServiceCreate() {
  const entity = 'service';  // Définir l'entité comme 'service'
  const translate = useLanguage();  // Fonction de traduction
  const Labels = {
    PANEL_TITLE: translate('service'),  // Titre du panneau pour le service
    DATATABLE_TITLE: translate('service_list'),  // Titre pour la liste des services
    ADD_NEW_ENTITY: translate('add_new_service'),  // Label pour ajouter un nouveau service
    ENTITY_NAME: translate('service'),  // Nom de l'entité
  };

  // Configuration de la page
  const configPage = {
    entity,
    ...Labels,  // Ajout des labels à la configuration
  };

  return <CreateServiceModule config={configPage} />;  // Retourner le module de création avec la configuration
}
