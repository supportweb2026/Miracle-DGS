import useLanguage from '@/locale/useLanguage';

import UserAddModule from '@/modules/SettingModule/UserAddModule';

export default function UserAddSettings() {
  const translate = useLanguage();

  const entity = 'setting';

  const Labels = {
    PANEL_TITLE: translate('utilisateurs'),
    DATATABLE_TITLE: translate('liste_utilisateurs'),
    ADD_NEW_ENTITY: translate('ajouter_utilisateur'),
    ENTITY_NAME: translate('utilisateur'),

    SETTINGS_TITLE: translate("Nouvel utilisateur"),
  };

  const configPage = {
    entity,
    settingsCategory: 'user_settings',
    ...Labels,
  };

  return <UserAddModule config={configPage} />;
}
