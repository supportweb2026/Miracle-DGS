import { useEffect, useState } from 'react';

export default function GlobalNotificationBanner({ message }) {
  const [show, setShow] = useState(!!message);

  useEffect(() => {
    if (message) {
      setShow(true);
      const timer = setTimeout(() => setShow(false), 10000); // 10 sec affichage
      return () => clearTimeout(timer);
    }
  }, [message]);

  if (!show) return null;

  return (
    <div className="fixed bottom-4 right-0 w-full z-50 pointer-events-none">
      <div className="mx-auto max-w-xl bg-blue-600 text-white py-2 px-4 rounded shadow animate-marquee">
        🔔 {message}
      </div>

      <style jsx>{`
        .animate-marquee {
          animation: scroll-left 10s linear infinite;
          white-space: nowrap;
        }
        @keyframes scroll-left {
          from {
            transform: translateX(100%);
          }
          to {
            transform: translateX(-100%);
          }
        }
      `}</style>
    </div>
  );
}
